# Research Brief: [Title of Your Research Project]

<!-- RESEARCH BRIEF TEMPLATE v1.0
     Single source of truth for all domain-specific configuration in the
     generalized research pipeline. The 10 pipeline skills read this file;
     they contain no domain knowledge of their own.
     Instructions appear in HTML comments. Delete them after filling in.
     Lines starting with "e.g." are examples — replace with your content. -->

## 1. Problem Statement

**Domain**: <!-- e.g., computational biology, econometrics, NLP -->
**Research area**: <!-- e.g., protein structure prediction, causal inference -->

**Core challenge**: <!-- 1-2 sentences. What is hard and why? -->

**Why existing approaches fall short**:
<!-- Bullet list: what current methods miss, get wrong, or cannot handle. -->

**Abstract problem formulation**:
<!-- Strip away domain specifics so the methodology architect can search
     across disciplines. Format as a blockquote. -->
> Given [input/setting], how do you optimally [objective] — while being
> robust to [key failure mode]?

## 2. Data Assets

### Primary Dataset
- **Description**: <!-- What does each row represent? -->
- **Location**: <!-- Relative path, e.g., data/trials_data.csv -->
- **Size**: <!-- e.g., 35 rows x 8 columns, 10 GB images -->
- **Key columns/features**: <!-- List the columns or features that matter -->
- **Response/outcome variable**: <!-- What are we trying to estimate or predict? -->

### Secondary Datasets
<!-- Repeat the block above for each additional dataset, or write "None." -->

### Data Quirks and Known Issues
<!-- Missing values, class imbalance, measurement error, censoring, etc. -->

### Infrastructure Code
<!-- Existing scripts for data loading/cleaning/preprocessing.
     e.g., data_curation.py — loading, cleaning, simulation -->

## 3. Domain Context

### Key Terminology
<!-- Define 5-15 terms a non-specialist needs. Use a definition-list format. -->

### Domain Constraints
<!-- Regulatory, ethical, computational, or practical constraints.
     e.g., FDA requires pre-specified analysis plans -->

### Standards and Conventions
<!-- Notation, workflow, or evaluation protocols the field uses.
     e.g., CONSORT reporting, ImageNet benchmark protocol -->

### Practitioner Expectations
<!-- What does the target audience need from a new method?
     e.g., interpretability, reproducibility, toolchain integration -->

## 4. Target Venue

**Name**: <!-- e.g., Biometrics, NeurIPS, Journal of Econometrics -->

### Format Requirements
- **Document class / template**: <!-- e.g., biom.cls, neurips_2025.sty -->
- **Page/word limit**: <!-- e.g., 20-30 pages double-spaced -->
- **Citation style**: <!-- e.g., author-year, numbered -->
- **Supplementary material**: <!-- Allowed? Required? Separate file? -->

### Author exemplars and manuscript shape
- **Paper type and central question**:
- **Vault / original exemplar paths and versions**:
- **Main-body word target (excluding abstract, references, supplement)**:
- **Supplementary budget and separate-file preference**:
- **Selected main-text displays and running example**:
- **Inherited content that must remain in main text**:
<!-- Build manuscript_plan.md from original author papers. Keep full validation in
     the evidence archive; manuscript completeness does not mean printing all outputs. -->

### Audience
<!-- Who reads this venue? What is their background? -->

### Quality Expectations
<!-- Check all that apply and elaborate. -->
- [ ] Rigorous theory (proofs, convergence guarantees)
- [ ] Comprehensive empirical evaluation
- [ ] Comparison to established baselines
- [ ] Real-world application / case study
- [ ] Reproducibility (code, data availability)
- [ ] Clear practical value

### Typical Structure
<!-- e.g., Introduction, Related Work, Method, Theory, Experiments, Discussion -->

## 5. Success Criteria

### Primary Metric(s)
<!-- Name, definition, meaningful improvement threshold.
     e.g., MSE of point estimates; 5%+ improvement over best baseline -->

### Secondary Metrics
<!-- Additional metrics that matter but are not the headline result. -->

### Calibration / Uncertainty
<!-- e.g., 95% CI coverage in [0.90, 0.97]; well-calibrated probabilities -->

### Robustness
<!-- What should the method withstand? e.g., irrelevant sources, missing data -->

### Computational Requirements
<!-- e.g., interactive speed (< 10 sec), trainable overnight on 1 GPU -->

### Deployability
<!-- Can practitioners use this? What infrastructure does it assume? -->

### Interpretability
<!-- How important is it that users understand WHY the method gives its answer? -->

## 6. Comparator Methods

<!-- ALL listed comparators MUST appear in ALL evaluation tables — the pipeline
     enforces this. 4-8 comparators is typical. -->

| # | Name | Reference | Brief Description | Why Included |
|---|------|-----------|-------------------|--------------|
| 1 | <!-- e.g., Pooled --> | <!-- citation --> | <!-- 1 sentence --> | <!-- reason --> |
| 2 | | | | |
| 3 | | | | |

## 7. Adjacent Fields

<!-- Helps the methodology architect search OUTSIDE your home field. -->

**Abstract version of the problem**:
<!-- Restate the problem in domain-neutral language (can repeat from Sec 1). -->

**Fields with analogous challenges** (list 3-6):

| Field | Analogous Concept | Key Reference |
|-------|-------------------|---------------|
| <!-- e.g., transfer learning --> | <!-- e.g., domain adaptation with source selection --> | <!-- author, year --> |
| | | |
| | | |

## 8. Evaluation Design

### Computational Budgets

| Stage | Replicates | Time Limit | Purpose |
|-------|-----------|------------|---------|
| Quick validation | <!-- e.g., 200 --> | <!-- e.g., 5 min --> | Sanity check during development |
| Stress test | <!-- e.g., 500 --> | <!-- e.g., 30 min --> | Robustness under edge cases |
| Production | <!-- e.g., 2000 --> | <!-- e.g., 2 hr --> | Final numbers for the paper |

### Evaluation Types
<!-- Check all that apply. -->
- [ ] Simulation study (synthetic data, known ground truth)
- [ ] Cross-validation (leave-one-out, k-fold, etc.)
- [ ] Held-out real data
- [ ] Sensitivity analysis (hyperparameters, assumptions)
- [ ] Robustness / stress tests (adversarial scenarios)
- [ ] Scalability benchmarks

### Random Seed Convention
<!-- e.g., base seed 42, increment by 1 per replicate -->

### Key Stress-Test Scenarios
<!-- Specific scenarios the method must survive.
     e.g., "Add 10 irrelevant sources, verify < 2% degradation" -->

## 9. Scope and Non-Goals

### What the Paper Should NOT Try to Do
<!-- Prevents scope creep. e.g., "Do not attempt causal inference."
     e.g., "Do not extend to time-to-event outcomes." -->

### Known Limitations to Acknowledge
<!-- Limitations to state upfront, not fix. e.g., "Assumes exchangeability." -->

### Methods or Approaches Out of Scope
<!-- e.g., "Deep learning — dataset too small."
     e.g., "Bayesian nonparametrics — too complex for target audience." -->

## 10. Reference Papers

**Directory**: <!-- e.g., reference/ -->

### Key Papers
<!-- Optional: 3-5 must-read papers with one-line descriptions.
     e.g., Schmidli et al. (2014) — robust MAP prior for historical borrowing -->

## Contribution and impact evidence
- **Declared genre and strongest proposed contribution**:
- **Closest author/vault precedents and external published benchmarks**:
- **Exact difference from prior work (established / verified here / unverified)**:
- **Intended user, decision/inference changed, and credible alternative**:
- **Decisive evaluation and failure condition**:
- **Impact evidence available versus proposed**:
<!-- Establish contribution_dossier.md before drafting. Do not count prestige,
     length, or self-objective optimality as evidence of a substantive advance. -->
